
package proyectocalidad;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import simulacion1.proyectocalidad.Testing;

public class NewMain {
    public static void main(String[] args) {
        Testing proyecto = new Testing();

       
    }
    
}
